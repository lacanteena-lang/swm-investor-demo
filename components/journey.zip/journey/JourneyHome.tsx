"use client";

import { motion } from "framer-motion";

import ScreenLayout from "../layout/ScreenLayout";

import SectionHeader from "../ui/SectionHeader";

import JourneyMap from "./JourneyMap";
import LiveJourneyMetrics from "./LiveJourneyMetrics";
import JourneyStatus from "./JourneyStatus";
import JourneyTimeline from "./JourneyTimeline";
import JourneyStats from "./JourneyStats";

type Props = {
  activeTab: string;
  setActiveTab: (tab: string) => void;
};

export default function JourneyHome({
  activeTab,
  setActiveTab,
}: Props) {
  return (
    <ScreenLayout
      activeTab={activeTab}
      setActiveTab={setActiveTab}
    >
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
        className="relative flex h-full flex-col overflow-y-auto no-scrollbar px-5 pt-4 pb-36"
      >
        {/* Background Glow */}

        <div className="pointer-events-none absolute inset-0">

          <div className="absolute left-1/2 top-[-200px] h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-cyan-400/10 blur-[150px]" />

          <div className="absolute bottom-[-150px] left-1/2 h-[320px] w-[320px] -translate-x-1/2 rounded-full bg-blue-500/10 blur-[120px]" />

        </div>

        {/* Content */}

        <div className="relative flex h-full flex-col px-5 pt-4 pb-4">

          <SectionHeader
            eyebrow="PROTECTED JOURNEY"
            title="Live Journey Monitoring"
            subtitle="AI continuously monitors your journey while your Personal Safety Concierge stays connected."
          />

          <div className="mt-5">
            <JourneyMap />
          </div>

          <div className="mt-4">
            <LiveJourneyMetrics />
          </div>

          <div className="mt-4">
            <JourneyStatus />
          </div>

          <div className="mt-4 flex-1 overflow-hidden">
            <JourneyTimeline />
          </div>

          <div className="mt-4">
            <JourneyStats />
          </div>

        </div>

      </motion.div>
    </ScreenLayout>
  );
}