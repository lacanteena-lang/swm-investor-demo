"use client";

import {
  Clock3,
  ShieldCheck,
  Bot,
} from "lucide-react";

import GlassCard from "../ui/GlassCard";
import PremiumMap from "./PremiumMap";

export default function JourneyMap() {
  return (
    <GlassCard className="p-6">

      {/* Header */}

      <div className="flex items-center justify-between">

        <div>

          <p className="text-[10px] font-semibold uppercase tracking-[0.32em] text-cyan-300">
            LIVE JOURNEY
          </p>

          <h2 className="mt-2 text-[28px] font-bold text-white">
            Protected Route
          </h2>

        </div>

        <div className="rounded-full bg-emerald-500/15 px-4 py-2">

          <span className="text-xs font-semibold text-emerald-300">
            ● AI Monitoring
          </span>

        </div>

      </div>

      {/* Premium Map */}

      <div className="relative mt-8 h-[500px] overflow-hidden rounded-3xl border border-cyan-400/10">

        <PremiumMap />

        {/* Floating Badge */}

        <div
          className="
            absolute
            left-4
            top-4
            rounded-full
            bg-black/70
            px-4
            py-2
            backdrop-blur-xl
          "
        >
          <span className="text-[10px] font-semibold uppercase tracking-[0.22em] text-cyan-300">
            AI MONITORING
          </span>
        </div>

      </div>

      {/* Bottom Cards */}

      <div className="mt-6 grid grid-cols-3 gap-3">

        {/* ETA */}

        <div className="rounded-2xl border border-white/5 bg-white/5 p-4">

          <Clock3
            size={20}
            className="text-cyan-300"
          />

          <p className="mt-2 text-xs text-white/50">
            ETA
          </p>

          <h3 className="mt-1 text-lg font-bold text-white">
            18 min
          </h3>

        </div>

        {/* AI */}

        <div className="rounded-2xl border border-white/5 bg-white/5 p-4">

          <Bot
            size={20}
            className="text-cyan-300"
          />

          <p className="mt-2 text-xs text-white/50">
            AI Status
          </p>

          <h3 className="mt-1 text-lg font-bold text-emerald-300">
            Active
          </h3>

        </div>

        {/* Concierge */}

        <div className="rounded-2xl border border-white/5 bg-white/5 p-4">

          <ShieldCheck
            size={20}
            className="text-cyan-300"
          />

          <p className="mt-2 text-xs text-white/50">
            Concierge
          </p>

          <h3 className="mt-1 text-lg font-bold text-emerald-300">
            Online
          </h3>

        </div>

      </div>

    </GlassCard>
  );
}