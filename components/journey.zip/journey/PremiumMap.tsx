"use client";
import L from "leaflet";
import {MapContainer,TileLayer,Marker,Polyline} from "react-leaflet";
import "leaflet/dist/leaflet.css";
const home:[number,number]=[28.6128,77.2065];
const office:[number,number]=[28.6139,77.2090];
const route:[number,number][]= [home,[28.6131,77.2072],[28.6135,77.2082],office];
const dot=(c:string)=>L.divIcon({className:"",html:`<div 
    style="width:22px;height:22px;border-radius:50%;background:${c};border:3px solid #fff;">
    </div>`,iconSize:[22,22],iconAnchor:[11,11]});
    export default function PremiumMap(){return(<div className="relative h-full w-full rounded-
        3xl overflow-hidden"><MapContainer center={[28.6134,77.2078]} zoom={16} scrollWheelZoom=
        {false} attributionControl={false} zoomControl={false} className="h-full w-full"><TileLayer 
        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png" attribution=""/><Polyline 
        positions={route} pathOptions={{color:"#38bdf8",weight:6,opacity:.95}}/><Marker position=
        {home} icon={dot("#22c55e")}/><Marker position={office} icon={dot("#ff3b30")}/><Marker 
        position={[28.6132,77.2076]} icon={dot("#00bfff")}/></MapContainer><div className="absolute 
        left-4 top-4 rounded-full bg-black/70 px-4 py-2 text-xs font-semibold tracking-[0.25em] 
        text-cyan-300 backdrop-blur-xl">AI MONITORING</div></div>);}